﻿using System;

namespace ITW_MobileApp
{
	public static class Constants
	{
		// Replace strings with your mobile services and gateway URLs.
		public static string ApplicationURL = @"https://itw-mobileapp.azurewebsites.net";
	}
}

